package com.lti.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="student_registration")
public class Student implements Serializable {
	@Id
	@Column(name="student_id")
	private int studentId;
	@Column(name="domicile_state")
	private String domicileState;
	@Column(name="student_name")
	private String studentName;
	@Column(name="gender")
	private String gender;
	@Column(name="mobile_number")
	private int mobileNumber;
	@Column(name="email_id")
	private String emailId;
	
	@Column(name="aadhar_number")
	private int aadharNumber;
	@Column(name="password")
	private String password;
	
	
	
	
	


	public Institute getInstitute() {
		return institute;
	}



	public void setInstitute(Institute institute) {
		this.institute = institute;
	}



	@ManyToOne
	@JoinColumn(name="institute_code")
	private Institute institute;
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Student(int studentId, String domicileState, String studentName, String gender, int mobileNumber,
			String emailId, int aadharNumber, String password) {
		super();
		this.studentId = studentId;
		this.domicileState = domicileState;
		this.studentName = studentName;
		this.gender = gender;
		this.mobileNumber = mobileNumber;
		this.emailId = emailId;
		this.aadharNumber = aadharNumber;
		this.password = password;
	}



	public int getStudentId() {
		return studentId;
	}



	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}



	public String getDomicileState() {
		return domicileState;
	}



	public void setDomicileState(String domicileState) {
		this.domicileState = domicileState;
	}



	public String getStudentName() {
		return studentName;
	}



	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}



	public String getGender() {
		return gender;
	}



	public void setGender(String gender) {
		this.gender = gender;
	}



	public int getMobileNumber() {
		return mobileNumber;
	}



	public void setMobileNumber(int mobileNumber) {
		this.mobileNumber = mobileNumber;
	}



	public String getEmailId() {
		return emailId;
	}



	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}



	public int getAadharNumber() {
		return aadharNumber;
	}



	public void setAadharNumber(int aadharNumber) {
		this.aadharNumber = aadharNumber;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
}